"""GluonCV motion dataset, supports multiple video tasks including
video action recognition/detection, object tracking, pose tracking, etc."""
from .dataset import GluonCVMotionDataset, FieldNames
