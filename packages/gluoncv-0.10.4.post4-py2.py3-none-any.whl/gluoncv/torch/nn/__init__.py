"""GluonCV-Torch neural network layers"""
