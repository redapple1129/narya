"""GluonCV-Torch pose estimation."""
from __future__ import absolute_import
from .directpose_resnet_fpn import *
