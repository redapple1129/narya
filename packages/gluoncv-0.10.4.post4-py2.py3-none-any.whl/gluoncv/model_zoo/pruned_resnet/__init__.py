"""GluonCV Model Zoo"""
# pylint: disable=wildcard-import
from ..resnetv1b import *
