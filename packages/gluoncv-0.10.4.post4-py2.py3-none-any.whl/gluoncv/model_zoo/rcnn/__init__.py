"""Fast RCNN."""
from __future__ import absolute_import

from .rcnn import RCNN
