"""Quantized versions of GluonCV models."""
# pylint: disable=wildcard-import
from .quantized import *
