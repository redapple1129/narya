"""GluonCV auto"""
from .estimators import *
