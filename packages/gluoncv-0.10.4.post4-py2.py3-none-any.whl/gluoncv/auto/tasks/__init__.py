"""AutoML Tasks"""
from .image_classification import *
from .object_detection import *
# from .utils import *
