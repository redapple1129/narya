"""Torch image classification estimator"""
from .torch_image_classification import TorchImageClassificationEstimator
