"""Image classification estimator"""
from .image_classification import ImageClassificationEstimator
