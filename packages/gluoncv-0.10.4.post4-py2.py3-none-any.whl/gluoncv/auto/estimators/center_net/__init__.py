"""SSD Estimator implementations"""

from .center_net import CenterNetEstimator
