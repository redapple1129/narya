"""SSD Estimator implementations"""

from .ssd import SSDEstimator
