"""Shared configs"""
_BEST_CHECKPOINT_FILE = 'best_checkpoint.pkl'
