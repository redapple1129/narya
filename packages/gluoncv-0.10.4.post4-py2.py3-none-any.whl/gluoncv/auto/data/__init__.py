"""Data Pipelines"""
from .auto_data import url_data, URLs, is_url
