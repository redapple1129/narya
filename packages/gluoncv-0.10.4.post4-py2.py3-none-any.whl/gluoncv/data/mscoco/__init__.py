"""MS COCO dataset."""
