# pylint: disable=wildcard-import
"""Video action recognition, something-something-v2 dataset.
https://20bn.com/datasets/something-something
"""
from __future__ import absolute_import
from .classification import *
