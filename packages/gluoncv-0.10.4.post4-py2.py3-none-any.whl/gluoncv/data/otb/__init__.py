# pylint: disable=wildcard-import
"""Object Tracking, Visual Tracker Benchmark
http://www.visual-tracking.net"""
from __future__ import absolute_import
from .tracking import *
