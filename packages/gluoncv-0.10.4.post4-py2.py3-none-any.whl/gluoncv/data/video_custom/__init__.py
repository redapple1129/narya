# pylint: disable=wildcard-import
"""
Customized data loader for video classification related tasks.
"""
from __future__ import absolute_import
from .classification import *
