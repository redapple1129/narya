"""autocfg library"""
from .dataclasses import dataclass, field, FrozenInstanceError
from .annotate import AnnotateField
